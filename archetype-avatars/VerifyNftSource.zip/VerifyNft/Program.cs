﻿using System.Security.Cryptography;

using Aes = System.Security.Cryptography.Aes;

Validator.Validate(args);

public class Validator
{
    public static void Validate(string[] args)
    {
        if (args is [_, "?"])
        {
            PrintUsage();
            return;
        }
        if (args.Length is < 3 or > 4)
        {
            Console.Out.WriteLine("Incorrect number of parameters");
            Console.Out.WriteLine("");
            PrintUsage();
            return;
        }

        var path = args[0];
        var numParam = args[1];
        var keyParam = args[2];
        string ivParam;
        if (args.Length == 3)
        {
            var tokens = args[2].Split(',');
            if (tokens.Length != 2)
            {
                Console.Out.WriteLine("Incorrect number of parameters");
                Console.Out.WriteLine("");
                PrintUsage();
                return;
            }
            keyParam = tokens[0];
            ivParam = tokens[1];
        }
        else
        {
            ivParam = args[3];
        }

        string[] encryptedLines;
        try
        {
            if (!File.Exists(path))
            {
                Console.Out.WriteLine($"File '{path}' does not exist");
                PrintUsage();
                return;
            }
            encryptedLines = File.ReadAllLines(path);
        }
        catch (Exception e)
        {
            Console.Out.WriteLine("Invalid file name for encrypted file.");
            Console.Out.WriteLine($"Error: {e.Message}");
            Console.Out.WriteLine("");
            PrintUsage();
            return;
        }

        int nftNumber;
        try
        {
            nftNumber = int.Parse(numParam);
            if (nftNumber < 1 || nftNumber > encryptedLines.Length)
            {
                Console.Out.WriteLine($"Nft number must be in the range of 1 to {encryptedLines.Length}");
                PrintUsage();
                return;
            }
        }
        catch
        {
            Console.Out.WriteLine("NftNumber parameter is not a valid integer");
            PrintUsage();
            return;
        }

        var aes = Aes.Create();
        try
        {
            var bytes = Convert.FromHexString(keyParam);
            if (bytes.Length != 32)
                throw new ArgumentException("Key is not the hex form of a 256 bit key");
            aes.Key = bytes;
        }
        catch (Exception e)
        {
            Console.Out.WriteLine("Unable to convert key parameter into a key");
            Console.Out.WriteLine($"Error: {e.Message}");
            Console.Out.WriteLine("");
            PrintUsage();
            return;
        }
        try
        {
            var bytes = Convert.FromHexString(ivParam);
            if (bytes.Length != 16)
                throw new ArgumentException("IV parameter is not the hex form of a 128 bit initialization vector");
            aes.IV = bytes;
        }
        catch (Exception e)
        {
            Console.Out.WriteLine("Unable to convert IV parameter into an initialization vector");
            Console.Out.WriteLine($"Error: {e.Message}");
            Console.Out.WriteLine("");
            PrintUsage();
            return;
        }

        var encryptedBytes =Convert.FromHexString( encryptedLines[nftNumber - 1]);

        using var memoryStream = new MemoryStream(encryptedBytes);
        var decryptor = aes.CreateDecryptor();
        var paddedId = new byte[16];
        using var cryptoStream = new CryptoStream(memoryStream, decryptor, CryptoStreamMode.Read);
        if (cryptoStream.Read(paddedId) != paddedId.Length)
        {
            Console.Out.WriteLine($"Unable to entry for NFT {nftNumber}");
            return;
        }

        var id = BitConverter.ToInt32(paddedId);
        Console.Out.WriteLine($"NFT number {nftNumber} maps to NFT id {id}");
    }

    private static void PrintUsage()
    {
        Console.Out.WriteLine("Usage:");
        Console.Out.WriteLine("  verifynft <file> <nftNumber> <key> <iv>");
        Console.Out.WriteLine("    nftNumber = the sequence number of your NFT");
        Console.Out.WriteLine("    file      = the encrypted nft mapping file path (EncryptedMap.txt)");
        Console.Out.WriteLine("    key       = decryption key as 256 bit byte array in hex string format");
        Console.Out.WriteLine("    iv        = initialization vector as 128 bit byte array in hex string format");
        Console.Out.WriteLine("Example:");
        Console.Out.WriteLine("  verifynft EncryptedMap.txt 55 93D2123418BAC7C4FF9CFA3DFD7785601BDAED5BBEB31694E1F8AF8B92E04CAE 09CE2AAA553D3DF62826613A23EF6062");
        Console.Out.WriteLine("or");
        Console.Out.WriteLine("  verifynft EncryptedMap.txt 55 93D2123418BAC7C4FF9CFA3DFD7785601BDAED5BBEB31694E1F8AF8B92E04CAE,09CE2AAA553D3DF62826613A23EF6062");
    }
}